//essa é a função que cria a tabela
 function calcularTabela(){

    //aqui eu capturo o número colocado no input
    let numero = parseInt(document.getElementById("numero").value);

    //aqui nós fazemos uma injeção de Html na variável tabela
    let tabela ="<table>";

    //aqui eu faço um laço de repetição para formas as minhas colunas 
    for(let i = 0;i<numero;i++){
        tabela = tabela+"<tr>"

        //aqui eu faço um laço para formar as minhas linhas
        for(let j = 0;j<numero;j++){

            let resultado = i+j;

            //aqui é para decidir se o quadrado vai ser preto ou branco
            if(resultado%2 == 0){
                tabela = tabela+"<td class='branco'></td>"
            }
            else{
                tabela = tabela+"<td class='preto'></td>"
            }
        }
        //aqui nós fechamos a coluna
        tabela = tabela+"</tr>"
    }
    
    //aqui fechamos a tabela
    tabela = tabela+"</table>"

    //aqui nós enviamos para o html a nossa tabela
    document.getElementById("saida").innerHTML = tabela;
}

//aqui eu registro o evento de clicar no botão em uma variável e assim q clicar ele realiza uma ação
let bnt = document.getElementById("bntCalcular");
bnt.addEventListener("click",calcularTabela);


